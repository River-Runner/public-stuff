﻿namespace NewGrowGrid
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string RulesSet = "";
            //introduction
            Console.WriteLine("Welcome to Elementary Cellular Automaton! (The simplest version of 1D cellular automaton)\n\n" +
                              "Here there are cells that can either be alive (\u25A0), or dead (\u00B7). what state they're in is determined by their rules:\n" +
                              "For example, an exciting rule is Rule 30 which is as follows:\n\n" +
                              "\t\u25A0 \u25A0 \u25A0 -> 0   \u25A0 \u25A0 \u00B7 -> 0   \u25A0 \u00B7 \u25A0 -> 0   \u25A0 \u00B7 \u00B7 -> 1   \u00B7 \u25A0 \u25A0 -> 1   \u00B7 \u25A0 \u00B7 -> 1   \u00B7 \u00B7 \u25A0 -> 1   \u00B7 \u00B7 \u00B7 -> 0\n\n" +
                              "When you concatenate all of the above 0's and 1's together, then you end up with a rule number. Using the given rule above, we have rule 0001110 which is 30 in binary.\n\n" +
                              "The very first line will contain all dead cells with one alive cell in the center.\n" +
                              "For the next line, the cells will reference the three cells above them, and accoring to the rules will either be dead or alive.\n" +
                              "Thus these rules will repeat every \'Generation\' until the computer finds a good place to stop.\n\n" +
                              "Now it's your turn! enter in an 8-digit binary rule number to select the next rules! (I didn't add user validation here b/c of laziness)\n");

            RulesSet = (Console.ReadLine());
            Console.Clear();

            //Setting the size
            int size = 9;
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Enter an odd natural number! (this will be the size of the first line)");
                string u_input = Console.ReadLine();
                if (int.TryParse(u_input, out size) && int.Parse(u_input) > 0 && int.Parse(u_input) % 2 != 0)
                {
                    size = int.Parse(u_input);
                    break;
                }
            }
            Console.Clear();

            //Building + Drawing the grid
            Mesh grid = new Mesh(size);
            grid.RuleChange(RulesSet);

            Console.WriteLine(grid.DrawNextLine());

            for (int i = 1; i <= 3*size; i++) //upper limit:   i <= ((size + 1) / 2) - 1;
            {
                //set values for next/previous line [okay]
                grid.SetNextAndPreviousLine(i);


                //calculate values in next line             
                grid.CalculateNextLine();


                //set values for next line                  
                grid.SetNextLine();


                //draw next line
                Console.WriteLine(grid.DrawNextLine());

                //Thread.Sleep(100)
            }
            Console.WriteLine("\n\n");
            //Cool ones involve:
            // The ravine    = 11100001 (225)
            // Epic triforce = 10100101 (165)
            // Black/white   = 00111001 (57) or 01100011 (99)
            // Serpinki's    = 10010110 (150)
            // Mounds        = 01101001 (105)
            // Crazy         = 01011001 (89)
        }
    }
}
