﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewGrowGrid
{
    internal class Mesh
    {
        //useful arrays
        public int[,] rulesForm = { { 1, 1, 1 }, { 1, 1, 0 }, { 1, 0, 1 }, { 1, 0, 0 }, { 0, 1, 1 }, { 0, 1, 0 }, { 0, 0, 1 }, { 0, 0, 0 } }; // left cell = 1, middle cell = 3, right cell = 5
        public string oneRule = "1358";
        public string zeroRule = "0469";

        //Actual attribues
        private int lineLength;
        private int[] seedLine;

        private int[] nextLine;
        public int[] NextLine { set; get; }

        private int[] previousLine;

        //Constructors and such
        public Mesh(int size)
        {
            lineLength = size;
            int[] array = new int[lineLength];
            int[] array2 = new int[lineLength];
            nextLine = array;
            previousLine = array2; //Note to self: DO NOT define two private atribues by setting them both equal to one variable!!!
            seedLine = array;
            seedLine[(size) / 2] = 1; //This part looks strange since array positions start at 0.
        }

        //The protocall
        public string DrawNextLine() //Draw the line
        {
            string desc = " ";
            foreach (int value in nextLine)
            {
                if (value == 1) { desc += "\u25A0 "; } //alive cell
                else { desc += "\u00B7 "; } // dead cell
            }
            return desc;
        }
        public void SetNextAndPreviousLine(int turn) //Set previousLine to seedLine or NextLine. Then clear the NextLine
        {
            if (turn == 1)
            {
                for (int i = 0; i < seedLine.Length; i++)
                {
                    previousLine[i] = seedLine[i];
                }
                //previous line is the seed line, and the next line is already empty
            }
            else
            {
                for (int i = 0; i < nextLine.Length; i++)
                {
                    previousLine[i] = nextLine[i];
                }
                //previous line is now the past next line, and the next line is ready to be overwritten
            }
        }
        public void CalculateNextLine() //Calculate rule values for all entries in NextLine
        {
            int next = 0;
            for (int i = 0; i < lineLength; i++)
            {
                if (i == 0)
                {
                    next += (0 * 1) + (previousLine[i] * 3) + (previousLine[i + 1] * 5);
                }
                else if (i == lineLength - 1)
                {
                    next += (previousLine[i - 1] * 1) + (previousLine[i] * 3) + (0 * 5);
                }
                else
                {
                    next += (previousLine[i - 1] * 1) + (previousLine[i] * 3) + (previousLine[i + 1] * 5);
                }
                nextLine[i] = next;
                next = 0;
            }
            //later generalize this method for any set of rules
        }
        public void SetNextLine()//Convert all rule values in NextLine to 1's and 0's
        {
            for (int i = 0; i < lineLength; i++)
            {
                if (oneRule.Contains(nextLine[i].ToString())) { nextLine[i] = 1; }
                else if (zeroRule.Contains(nextLine[i].ToString())) { nextLine[i] = 0; }
                else { throw new Exception("NextLine contains a value that is not included in the rules"); }
            }
        }

        //Error checking and useful tools
        public string ReturnNextLine()
        {
            string desc = " ";
            foreach (int value in nextLine)
            {
                desc += value + " ";
            }
            return desc;
        }
        public string ReturnPreviousLine()
        {
            string desc = " ";
            foreach (int value in previousLine)
            {
                desc += value + " ";
            }
            return desc;
        }

        //Setting the rules
        public static int CellValue(int number)
        {
            switch (number)
            {
                case 1:
                    return 9;
                case 2:
                    return 4;
                case 3:
                    return 6;
                case 4:
                    return 1;
                case 5:
                    return 8;
                case 6:
                    return 3;
                case 7:
                    return 5;
                case 8:
                    return 0;
                default:
                    throw new Exception("Something got messed up in the RuleChange method.");
            }
        }
        public void RuleChange(string number) //NOT finished
        {
            string Alive = "";
            string Dead = "";
            char[] array = number.ToCharArray();
            if (array.Length != 8) { throw new Exception("User did not enter an 8 digit number."); }
            for (int i = 0; i < 8; i++)
            {
                if (array[i] == '1') { Alive += CellValue(i + 1).ToString(); }
                else { Dead += CellValue(i + 1).ToString(); }
            }
            oneRule = Alive;
            zeroRule = Dead;
        }
    }
}
